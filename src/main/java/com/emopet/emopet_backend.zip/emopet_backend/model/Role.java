package com.emopet.emopet_backend.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
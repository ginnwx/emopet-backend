package com.emopet.emopet_backend.payload;

public class UpdateUsernameRequest {
    private String username;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
}
